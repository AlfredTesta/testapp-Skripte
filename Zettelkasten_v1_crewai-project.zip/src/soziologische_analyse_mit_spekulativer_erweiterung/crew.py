import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	EXASearchTool
)






@CrewBase
class SoziologischeAnalyseMitSpekulativerErweiterungCrew:
    """SoziologischeAnalyseMitSpekulativerErweiterung crew"""

    
    @agent
    def recherche_spezialist_scout(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["recherche_spezialist_scout"],
            
            
            tools=[				EXASearchTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def creative_copywriter(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["creative_copywriter"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def kreativer_stoerer_quasselstrippe(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["kreativer_stoerer_quasselstrippe"],
            
            
            tools=[				EXASearchTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def begriffswachter_nomenklator(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["begriffswachter_nomenklator"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def wissenschaftlicher_protokollant_system_chronist(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["wissenschaftlicher_protokollant_system_chronist"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    

    
    @task
    def analyse_und_recherche_zu_thema(self) -> Task:
        return Task(
            config=self.tasks_config["analyse_und_recherche_zu_thema"],
            markdown=False,
            
            
        )
    
    @task
    def glossar_abgleich_und_anreicherung(self) -> Task:
        return Task(
            config=self.tasks_config["glossar_abgleich_und_anreicherung"],
            markdown=False,
            
            
        )
    
    @task
    def assoziative_und_spekulative_erweiterung(self) -> Task:
        return Task(
            config=self.tasks_config["assoziative_und_spekulative_erweiterung"],
            markdown=False,
            
            
        )
    
    @task
    def notiz_zettel_fuer_obsidian(self) -> Task:
        return Task(
            config=self.tasks_config["notiz_zettel_fuer_obsidian"],
            markdown=False,
            
            
        )
    
    @task
    def prozess_protokollierung_und_journal(self) -> Task:
        return Task(
            config=self.tasks_config["prozess_protokollierung_und_journal"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the SoziologischeAnalyseMitSpekulativerErweiterung crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


